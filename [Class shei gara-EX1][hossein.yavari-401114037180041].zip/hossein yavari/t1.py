x = 5

if x < 10:
    print('smaller')
if x > 20:
    print('Bigger')

print('Finish')        