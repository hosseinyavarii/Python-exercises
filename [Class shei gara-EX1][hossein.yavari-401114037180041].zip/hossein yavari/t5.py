x = 5
if x < 2 :
    print('Small')
elif x < 10 :
    print('Medium')

print('All done')
