H = 10
print('Hello')

def print_my_statics():
    print("I'm a learner.")
    print('I have a goal for my life and I strive to achieve my goal :) .')

print_my_statics()
H = H + 7
print(H)
