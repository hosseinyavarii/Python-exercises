#type
hesab = 124 + 5342
print (hesab)
# type with words :
y = 'thanks' + ' God'
print (y)
