# last Exercise
Hours = 44
Rate = 3.50
Pay = Hours * Rate
print ( Pay)