Old = input('How old are you ? ')
print (Old + " is a good age !")
