def hossein():
    print('hi')
    print('hossein !')
 
hossein()
print('Next')
hossein()
