x = 16
if x < 20 :
    print ('x is smaller than 20')
elif x > 20 :
    print ('number us bigger than 20')
print ('finish')
