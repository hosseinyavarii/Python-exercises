print(float(420) + 829)
x = 317
type(x)
Fl1 = float(x)
print(Fl1)
type(Fl1)
