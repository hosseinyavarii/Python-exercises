a = int(input("please enter a Number : "))
if a < 2 :
    print('small')
elif a < 10 :
    print('Medium')
else :
    print('LARGE')
print('Well done')
