big = max (str(input('please write a Sting :')))
print ('biggest word is : ' + big)