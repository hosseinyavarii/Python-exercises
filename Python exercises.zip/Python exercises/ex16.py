'Expression tutorial Addition :'
w= 9
w= w + 3
print (w)
'Expression tutorial Multiplication :'
x= 4
x= x * 5
print (x)
'Expression tutorial Division :'
y= 22
y= y / 2
print (y)
'Expression tutorial Remainder :'
z = 17
z= z % 3
print (z)
